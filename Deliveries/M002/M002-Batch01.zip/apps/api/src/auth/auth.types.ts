export interface JwtPayload {
  sub: string;
  email?: string;
  memberId?: string;
  sessionId: string;
  roles: string[];
  tokenVersion: number;
}
