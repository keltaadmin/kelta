Verification procedure.
