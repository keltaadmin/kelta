export class SubmitApplicationDto {}
