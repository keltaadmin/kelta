# M002 Batch 01

Foundation files for the KELTA authentication module.
Next batch will implement AuthService, JWT strategy and controller.
