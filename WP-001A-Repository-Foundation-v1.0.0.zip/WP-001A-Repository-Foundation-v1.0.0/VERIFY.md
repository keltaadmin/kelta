Verification succeeds when required folders exist.
