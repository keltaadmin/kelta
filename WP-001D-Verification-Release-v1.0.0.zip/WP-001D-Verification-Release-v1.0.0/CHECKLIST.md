Release checklist.
