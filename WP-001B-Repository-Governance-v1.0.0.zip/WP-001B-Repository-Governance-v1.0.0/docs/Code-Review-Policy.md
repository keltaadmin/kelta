Review checklist.
