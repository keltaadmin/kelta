Extract into D:\KELTA then run:

.\scripts\bootstrap.ps1
.\scripts\verify.ps1
