
$req=@("Product","Architecture","Engineering","ProjectControl","Templates","Assets","Audit","apps","packages","infrastructure","scripts")
$ok=$true
foreach($r in $req){if(!(Test-Path $r)){Write-Host "Missing $r";$ok=$false}}
if($ok){Write-Host "PASSED"}else{Write-Host "FAILED";exit 1}
