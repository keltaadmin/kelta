Module ownership guidance.
