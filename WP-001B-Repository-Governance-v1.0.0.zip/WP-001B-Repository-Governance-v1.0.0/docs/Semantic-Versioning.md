Use SemVer.
