export const JWT_ACCESS_TOKEN_TTL = '15m';
export const JWT_REFRESH_TOKEN_TTL = '30d';
export const BCRYPT_ROUNDS = 12;
