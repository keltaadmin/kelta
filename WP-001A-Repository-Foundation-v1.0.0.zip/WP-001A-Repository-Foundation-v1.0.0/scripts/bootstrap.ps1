
Write-Host "Bootstrapping..."
$folders=@("Product","Architecture","Engineering","ProjectControl","Templates","Assets","Audit","apps","packages","infrastructure","scripts")
foreach($f in $folders){if(!(Test-Path $f)){New-Item -ItemType Directory -Path $f|Out-Null}}
Write-Host "Done."
